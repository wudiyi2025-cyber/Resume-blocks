// Deterministic extraction for the role / dates / company / bullet layout in the supplied resumes.
// Nothing in an uploaded document is executed or treated as an instruction.
const month = '(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan\\.?|Feb\\.?|Mar\\.?|Apr\\.?|Jun\\.?|Jul\\.?|Aug\\.?|Sep\\.?|Sept\\.?|Oct\\.?|Nov\\.?|Dec\\.?)';
const dateAtom = `(?:${month}\\s+\\d{4}|\\d{4}[年./-]\\d{1,2}月?|(?:19|20)\\d{2}(?![\\d.\\p{L}]))`;
const datePattern = new RegExp(`\\b${dateAtom}(?:\\s*[-–—~至到]\\s*(?:${dateAtom}|Present|Now|Current|至今))?`, 'iu');
const bulletPattern = /^\s*(?:[•●▪◦·]|[-*]\s|\d+[.)]\s)\s*/;
const workHeading = /^(?:work(?:ing)? experience|professional experience|employment(?: history)?|experience|工作经历|实习经历|项目经历)\s*$/i;
const endHeading = /^(?:certificate\w*\s*(?:&|and)?\s*(?:language|lauguage)?|certifications?(?:\s*(?:&|and)\s*languages?)?|skills(?:\s*&.*)?|languages?|education|教育(?:经历|背景)|证书.*|技能.*|语言.*)\s*$/i;
const rolePattern = /counsel|specialist|paralegal|intern|clerk|manager|director|engineer|analyst|assistant|associate|officer|lead|consultant|法务|律师|实习|经理|专员|助理|工程师|分析师/i;
const companyPattern = /co\.,?|ltd\.?|inc\.?|firm|university|company|corp|公司|事务所|集团|大学/i;

export function parseResume(text) {
  const lines = String(text).replace(/\r\n?/g, '\n').split('\n').map(l => l.replace(/\u00a0/g, ' ').trim()).filter(Boolean);
  const headingIndex = lines.findIndex(l => workHeading.test(l));
  const input = headingIndex >= 0 ? lines.slice(headingIndex + 1) : lines;
  const experiences = []; let current = null, headers = [], pendingBullet = '';
  const flushBullet = () => {
    if (pendingBullet.trim() && current) current.bullets.push(pendingBullet.replace(/\s+/g, ' ').trim());
    pendingBullet = '';
  };
  const startExperience = () => {
    flushBullet();
    const dateLine = headers.find(l => datePattern.test(l));
    const dates = dateLine?.match(datePattern)?.[0] || '';
    const clean = headers.map(l => (l === dateLine ? l.replace(datePattern, '') : l).replace(/^[\s|,;]+|[\s|,;]+$/g, '').trim()).filter(Boolean);
    let role = '', company = '';
    if (clean.length === 1 && /\s\|\s/.test(clean[0])) {
      const chunks = clean[0].split(/\s\|\s/);
      const roleIndex = chunks.findIndex(c => rolePattern.test(c) && !companyPattern.test(c));
      if (roleIndex >= 0) { role = chunks[roleIndex]; company = chunks.filter((_, i) => i !== roleIndex).join(' | '); }
      else { role = chunks[0]; company = chunks.slice(1).join(' | '); }
    } else {
      const roleIndex = clean.findIndex(c => rolePattern.test(c) && !companyPattern.test(c));
      if (roleIndex >= 0) { role = clean[roleIndex]; company = clean.filter((_, i) => i !== roleIndex).join(' '); }
      else if (clean.length > 1 && companyPattern.test(clean[0])) { company = clean[0]; role = clean.slice(1).join(' '); }
      else { role = clean[0] || ''; company = clean.slice(1).join(' '); }
    }
    current = { role, company, dates, bullets: [] };
    experiences.push(current); headers = [];
  };
  for (const line of input) {
    if (endHeading.test(line)) break;
    if (workHeading.test(line)) continue;
    if (bulletPattern.test(line)) {
      flushBullet();
      if (headers.length || !current) startExperience();
      pendingBullet = line.replace(bulletPattern, '');
      continue;
    }
    const isHeader = datePattern.test(line) && (!pendingBullet || (rolePattern.test(line) && line.length < 160));
    if (isHeader) { flushBullet(); headers.push(line); }
    else if (pendingBullet && headers.length === 0) pendingBullet += ` ${line}`;
    else headers.push(line);
  }
  flushBullet();
  if (headers.length && !experiences.length) startExperience();
  // A header without bullets remains visible for manual completion, never silently discarded.
  return {
    experiences,
    warnings: experiences.flatMap((e, i) => [!e.role && `第 ${i + 1} 段缺少职位`, !e.company && `第 ${i + 1} 段缺少公司`, !e.dates && `第 ${i + 1} 段缺少时间`, !e.bullets.length && `第 ${i + 1} 段尚无经历要点`].filter(Boolean))
  };
}
