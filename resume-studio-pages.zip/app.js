import { splitParagraphs, similarity } from './batch.js';
import { interfaceLanguage, setInterfaceLanguage, translateInterface } from './interface-language.js';
import { validState } from './validation.js';
import { CloudSync } from './cloud.js';
import { SEED } from './seed.js';
import { parseResume } from './parser.js';
import { extractPdf } from './pdf-import.js';
import { SECTIONS, orderedKeys, migrateState } from './model.js';

const STORAGE = 'resume-studio-v1';
let cloud=null,editorReady=false,hadLocalData=false;
const clone = value => structuredClone(value);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const uid = () => crypto.randomUUID();
const icons = {
  file:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v5h4M9 12h6M9 16h6"/>',
  library:'<rect x="4" y="4" width="16" height="17" rx="2"/><path d="M8 4v17M12 9h4M12 13h4"/>',
  folder:'<path d="M3 7V5a1 1 0 0 1 1-1h5l2 3h9a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  upload:'<path d="M12 16V3M7 8l5-5 5 5M4 15v5h16v-5"/>',
  download:'<path d="M12 3v13M7 11l5 5 5-5M4 16v5h16v-5"/>',
  search:'<circle cx="10" cy="10" r="6"/><path d="m15 15 5 5"/>',
  chevron:'<path d="m9 5 7 7-7 7"/>',
  close:'<path d="m6 6 12 12M6 18 18 6"/>',
  up:'<path d="m6 14 6-6 6 6"/>',
  down:'<path d="m6 10 6 6 6-6"/>',
  settings:'<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2" fill="currentColor"/><circle cx="15" cy="12" r="2" fill="currentColor"/><circle cx="9" cy="18" r="2" fill="currentColor"/>',
  edit:'<path d="m15 4 5 5M4 20l5-1L21 7l-5-5L4 14z"/>',
  copy:'<rect x="8" y="8" width="12" height="13" rx="1"/><path d="M15 8V3H3v13h5"/>',
};
const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">${icons[name] || icons.file}</svg>`;

let initialError = '';
let state = clone(SEED);
try {
  const saved = localStorage.getItem(STORAGE);
  if (saved) {
    const data = JSON.parse(saved);
    if (validState(data)) { state = data;hadLocalData=true; }
    else initialError = '保存的数据格式有误，已加载初始经历库。原数据尚未被覆盖。';
  }
} catch { initialError = '无法读取本地保存。可以继续编辑，请及时下载备份。'; }
let saveFailed = false;
const migrated = migrateState(state);
const ui = { route:'editor', tab:'library', category:'all', search:'', openCards:new Set(['qingxian','enniu']), fits:true, font:13.4, filterDirty:false, alphabetical:false };
const app = document.querySelector('#app');
const modal = document.querySelector('#modal');
const langData = () => state.languages[state.activeLang];
const draft = () => langData().drafts.find(d => d.id === langData().activeDraft);
const allBullets = () => langData().experiences.flatMap(e => e.bullets);
const categoryName = id => state.categories.find(c=>c.id===id)?.name || '';
const selectedCount = () => draft().selected.filter(id=>allBullets().some(b=>b.id===id)).length;
let toastTimer;
function toast(message) {
  const el = document.querySelector('#toast');
  el.textContent = message; el.classList.add('visible');
  clearTimeout(toastTimer); toastTimer = setTimeout(()=>el.classList.remove('visible'), 4200);
}
function save() {
  try { localStorage.setItem(STORAGE, JSON.stringify(state)); saveFailed = false; }
  catch { saveFailed = true; toast('浏览器空间不足或禁止保存，请下载数据备份。'); }
  cloud?.schedule();
}
function syncStatus(){
  return cloud?.enabled?`<button class="save-status cloud-sync-status ${cloud.status==='conflict' || cloud.status==='expired'?'save-warning':''}" data-action="account">${esc(cloud.label)}</button>`:`<span class="save-status ${saveFailed?'save-warning':''}">${saveFailed?'尚未保存，请下载备份':'修改已自动保存'}</span>`;
}
function updateCloudStatus(){
  const el=document.querySelector('.cloud-sync-status');
  if(el){el.textContent=cloud.label;el.classList.toggle('save-warning',['conflict','expired','offline'].includes(cloud.status));}
}
function capture() {
  document.querySelectorAll('.experience-card').forEach(el => el.open ? ui.openCards.add(el.dataset.exp) : ui.openCards.delete(el.dataset.exp));
  return { library:document.querySelector('.experience-list')?.scrollTop || 0, paper:document.querySelector('.paper-area')?.scrollTop || 0 };
}
function tags(b) { return b.categories.filter(id=>categoryName(id)).map(id=>`<span class="tag">${esc(categoryName(id))}</span>`).join(''); }
function filterBullet(e,b) {
  const search = ui.search.trim().toLocaleLowerCase();
  return (ui.category==='all' || b.categories.includes(ui.category)) && (!search || `${e.role} ${e.company} ${b.text}`.toLocaleLowerCase().includes(search));
}
function categoriesFilter() {
  return `<div class="filter-chips"><button class="chip ${ui.category==='all'?'active':''}" data-action="filter" data-id="all">全部</button>${state.categories.map(c=>`<button class="chip ${ui.category===c.id?'active':''}" data-action="filter" data-id="${esc(c.id)}">${esc(c.name)}</button>`).join('')}</div>`;
}
function searchField() {
  return `<div class="search-wrap">${icon('search')}<input type="search" id="search" placeholder="搜索公司、职位或经历内容" aria-label="搜索经历" value="${esc(ui.search)}"></div>`;
}
function render() {
  const scroll = capture();
  const routeName = {editor:'简历制作',library:'经历库',categories:'分类管理'}[ui.route];
  app.innerHTML = `<div class="app-shell">
    <aside class="sidebar"><a class="brand" href="#editor" aria-label="简历工作室首页"><span class="brand-icon">${icon('file')}</span>简历工作室</a>
      <div class="side-label">我的工作台</div><nav class="nav-list" aria-label="主导航">
      ${[['editor','file','简历制作'],['library','library','经历库'],['categories','folder','分类管理']].map(([id,i,label])=>`<button class="nav-item ${ui.route===id?'active':''}" data-action="navigate" data-id="${id}" aria-label="${label}" ${ui.route===id?'aria-current="page"':''}>${icon(i)}${label}${id==='library'?`<span class="nav-count" aria-hidden="true">${allBullets().length}</span>`:''}</button>`).join('')}
      </nav><div class="side-bottom"><div class="local-note"><span class="status-dot"></span>${cloud?.enabled?'登录后跨设备同步':'保存在本机浏览器'}</div><p>${cloud?.enabled?'经历与简历会自动同步。<br>也可以下载一份数据备份。':'经历与修改会自动保存。<br>换设备前，请先下载备份。'}</p>${cloud?.enabled?'<button class="quiet small" data-action="account">账户与同步</button>':''}<div class="backup-actions"><button class="quiet" data-action="backup">下载备份</button><button class="quiet" data-action="restore">恢复备份</button></div></div>
    </aside><main class="main"><header class="topbar"><div class="breadcrumbs">我的工作台 <span>/</span> <strong>${routeName}</strong></div><div class="top-actions">${syncStatus()}<div class="language-switch" aria-label="简历语言"><button data-action="language" data-id="en" class="${state.activeLang==='en'?'active':''}" aria-pressed="${state.activeLang==='en'}">英文简历</button><button data-action="language" data-id="zh" class="${state.activeLang==='zh'?'active':''}" aria-pressed="${state.activeLang==='zh'}">中文简历</button></div><div class="language-switch" aria-label="Interface language"><button data-action="interface-language" data-id="zh" class="${interfaceLanguage()==='zh'?'active':''}" aria-pressed="${interfaceLanguage()==='zh'}">中文</button><button data-action="interface-language" data-id="en" class="${interfaceLanguage()==='en'?'active':''}" aria-pressed="${interfaceLanguage()==='en'}">English</button></div></div></header>
    <div class="workspace">${ui.route==='editor'?editorView():ui.route==='library'?libraryView():categoriesView()}</div></main></div>`;
  if (ui.route === 'editor') {
    refreshPreview();
    document.querySelector('.experience-list').scrollTop = scroll.library;
    document.querySelector('.paper-area').scrollTop = scroll.paper;
  }
  translateInterface(app);
}
function editorView() {
  return `<div class="page-heading"><div><div class="eyebrow">RESUME STUDIO</div><h1>制作你的${state.activeLang==='en'?'英文':'中文'}简历</h1><p>从经历库逐条选择，组合适合这次投递的简历。</p></div><div class="heading-actions"><button data-action="profile">${icon('edit')}基本信息</button><button data-action="sections">${icon('folder')}管理章节</button><button data-action="reorder">${icon('up')}调整顺序</button><button data-action="layout">${icon('settings')}排版</button><button class="primary" data-action="export">${icon('download')}导出简历</button></div></div>
  ${state.activeLang==='zh' && !langData().experiences.length?'<div class="notice">中文经历库尚未填写。你可以导入中文材料，或手动添加；中英文内容分别保存。</div>':''}
  <div class="draft-bar"><div class="draft-picker">${icon('file')}<select id="draft-select" aria-label="当前简历">${langData().drafts.map(d=>`<option value="${esc(d.id)}" ${d.id===draft().id?'selected':''}>${esc(d.name)}</option>`).join('')}</select><button class="quiet icon-button" data-action="rename-draft" title="修改简历名称" aria-label="修改简历名称">${icon('edit')}</button></div><div class="draft-options"><button class="quiet small" data-action="new-draft">${icon('plus')}新建</button><button class="quiet small" data-action="copy-draft">${icon('copy')}另存一份</button>${langData().drafts.length>1?'<button class="quiet small danger" data-action="delete-draft">删除</button>':''}</div></div>
  <div class="editor-grid"><section class="selection-panel" aria-label="选择经历"><div class="selection-top"><div class="panel-tabs"><button data-action="tab" data-id="library" class="${ui.tab==='library'?'active':''}">选择经历 <span>${allBullets().length}</span></button><button data-action="tab" data-id="selected" class="${ui.tab==='selected'?'active':''}">已选内容 <span>${selectedCount()}</span></button></div>${ui.tab==='library'?`${searchField()}${categoriesFilter()}`:'<p class="independent-note">可用上下箭头调整经历和要点顺序；教育、证书与各部分顺序可在上方“调整顺序”中修改。</p>'}</div>
  <div class="selection-summary"><span>${ui.tab==='library'?'勾选条目，即可加入右侧简历':`已选择 ${selectedCount()} 条经历要点`}</span><button class="quiet small" data-action="${ui.tab==='library'?'import':'clear-selection'}">${ui.tab==='library'?'导入经历':'清空选择'}</button></div><div class="experience-list" id="selection-list">${ui.tab==='library'?selectionList():selectedList()}</div></section>
  <section class="preview-panel" aria-label="简历预览"><div class="preview-toolbar"><strong>简历预览 <span class="muted">· ${state.activeLang==='en'?'English':'中文'} · Letter</span></strong><div class="preview-tools"><span id="page-badge" class="page-badge">正在排版</span><button class="small preview-sort-button" data-action="preview-reorder" aria-label="在预览中调整顺序">${icon('up')}调整顺序</button></div></div><div class="paper-area"><div class="paper-wrap preview-interactive" id="paper-wrap" data-action="preview-reorder" role="button" tabindex="0" aria-label="点击预览中的条目调整顺序" aria-describedby="preview-instruction" aria-haspopup="dialog"><article id="resume-preview" class="resume-page"></article><span class="preview-reorder-hint" aria-hidden="true">${icon('up')}点击调整顺序</span></div><div class="preview-caption"><span id="preview-instruction">点击预览中的条目，即可调整对应顺序</span><span>与原简历相同的单栏版式 · 8.5 × 11 英寸</span></div></div></section></div>`;
}
function selectionList() {
  const groups = langData().experiences.map(e=>({e,bullets:(ui.alphabetical?[...e.bullets].sort((a,b)=>a.text.localeCompare(b.text,undefined,{sensitivity:"base"})):e.bullets).filter(b=>filterBullet(e,b))})).filter(g=>g.bullets.length);
  if (!groups.length) return `<div class="empty-state">${icon('library')}<h3>${allBullets().length?'没有找到对应经历':'从第一段经历开始'}</h3><p>${allBullets().length?'试试其他分类或搜索词。':'导入已有简历，或在经历库手动添加。'}</p>${!allBullets().length?'<button class="small" data-action="import">导入经历</button>':''}</div>`;
  return groups.map(({e,bullets})=>`<details class="experience-card" data-exp="${esc(e.id)}" ${ui.openCards.has(e.id)||ui.search||ui.category!=='all'?'open':''}><summary><span class="chevron">${icon('chevron')}</span><div class="experience-info"><h3>${esc(e.role)}</h3><p class="company-short">${esc(e.company)}</p><p>${esc(e.dates)}</p></div><span class="experience-count">${e.bullets.filter(b=>draft().selected.includes(b.id)).length}/${e.bullets.length}</span></summary>${bullets.map(b=>`<div class="bullet-row ${draft().selected.includes(b.id)?'selected':''}"><input type="checkbox" id="select-${esc(b.id)}" data-select="${esc(b.id)}" ${draft().selected.includes(b.id)?'checked':''} aria-label="选择经历：${esc(b.text.slice(0,70))}"><div class="bullet-label"><label for="select-${esc(b.id)}" class="bullet-text">${esc(b.text)}</label><div class="bullet-footer">${tags(b)}<span class="source-label">${esc(b.sources.join(' / '))}</span><button class="quiet bullet-edit" data-action="edit-bullet" data-id="${esc(b.id)}" data-mode="library">编辑</button></div></div></div>`).join('')}</details>`).join('');
}
function orderedExperiences() {
  const data = langData(); const d = draft();
  return [...data.experiences].sort((a,b)=>{
    const ai=d.order.indexOf(a.id), bi=d.order.indexOf(b.id);
    return (ai<0?999:ai)-(bi<0?999:bi);
  }).map(e=>({...e,...d.metaOverrides[e.id],bullets:d.selected.map(id=>e.bullets.find(b=>b.id===id)).filter(Boolean)})).filter(e=>e.bullets.length);
}
function selectedList() {
  const groups=orderedExperiences();
  if (!groups.length) return '<div class="empty-state"><h3>还没有选择经历</h3><p>回到“选择经历”，勾选你希望加入的要点。</p></div>';
  return groups.map((e,ei)=>`<div class="selected-block"><div class="selected-block-heading"><div><strong>${esc(e.role)}</strong><div class="muted">${esc(e.company)}</div><button class="quiet small" data-action="edit-draft-meta" data-id="${esc(e.id)}">修改职位、公司与时间</button></div><div class="move-actions"><button class="icon-button quiet" data-action="move-experience" data-id="${esc(e.id)}" data-direction="-1" aria-label="上移经历" ${ei===0?'disabled':''}>${icon('up')}</button><button class="icon-button quiet" data-action="move-experience" data-id="${esc(e.id)}" data-direction="1" aria-label="下移经历" ${ei===groups.length-1?'disabled':''}>${icon('down')}</button></div></div>${e.bullets.map((b,bi)=>`<div class="selected-item"><p>${esc(draft().overrides[b.id]??b.text)}</p><div class="selected-item-footer"><div><button class="quiet small" data-action="edit-bullet" data-id="${esc(b.id)}" data-mode="draft">编辑文字</button><button class="quiet small danger" data-action="remove-bullet" data-id="${esc(b.id)}">移除</button></div><div class="move-actions"><button class="quiet icon-button" data-action="move-bullet" data-id="${esc(b.id)}" data-direction="-1" aria-label="上移要点" ${bi===0?'disabled':''}>${icon('up')}</button><button class="quiet icon-button" data-action="move-bullet" data-id="${esc(b.id)}" data-direction="1" aria-label="下移要点" ${bi===e.bullets.length-1?'disabled':''}>${icon('down')}</button></div></div></div>`).join('')}</div>`).join('');
}
function resumeMarkup() {
  const p=langData().profile, d=draft(), en=state.activeLang==='en';
  const contact = [p.phone,p.email,p.location].filter(Boolean).map(esc).join(' | ');
  const education = orderedKeys(d.educationOrder,p.education.map(e=>e.id)).map(id=>p.education.find(e=>e.id===id));
  const certificateLines = p.certificates.split('\n').filter(line=>line.trim());
  const certificates = orderedKeys(d.certificateOrder,certificateLines.map((_,i)=>i)).map(i=>({id:i,text:certificateLines[i]}));
  const sections = {
    education:d.showEducation && education.length?`<h2 class="resume-heading" data-preview-sort="sections" data-preview-key="education">${en?'Education':'教育背景'}</h2>${education.map(e=>`<div class="resume-education" data-preview-sort="education" data-preview-key="${esc(e.id)}"><div class="resume-row"><span class="resume-school">${esc(e.school)}</span><span class="resume-dates">${esc(e.dates)}</span></div><div class="resume-degree">${esc(e.degree)}</div></div>`).join('')}`:'',
    experience:'',
    certificates:d.showCertificates && certificates.length?`<h2 class="resume-heading" data-preview-sort="sections" data-preview-key="certificates">${en?'Certificate & Language':'证书与语言'}</h2><p class="resume-certificate">${certificates.map(c=>`<span data-preview-sort="certificates" data-preview-key="${c.id}">${esc(c.text)}</span>`).join('\n')}</p>`:''
  };
  for(const section of [{id:'experience',name:en?'Work Experience':'工作经历'},...(langData().customSections||[])]){
    const entries=orderedExperiences().filter(e=>(e.section || 'experience')===section.id);
    sections[section.id]=entries.length?`<h2 class="resume-heading" data-preview-sort="sections" data-preview-key="${esc(section.id)}">${esc(section.name)}</h2>${entries.map(e=>`<section class="resume-experience" data-preview-sort="experiences" data-preview-key="${esc(e.id)}"><div class="resume-row"><span class="resume-role">${esc(e.role)}</span><span class="resume-dates">${esc(e.dates)}</span></div><div class="resume-company">${esc(e.company)}</div><ul class="resume-bullets">${e.bullets.map(b=>`<li data-preview-sort="bullets-${esc(e.id)}" data-preview-key="${esc(b.id)}">${esc(d.overrides[b.id]??b.text)}</li>`).join('')}</ul></section>`).join('')}`:'';
  }
  return `<div class="resume-header"><h1 class="resume-name">${esc(p.name || (en?'Your Name':'姓名'))}</h1><span class="resume-contact">${contact}</span></div>${orderedKeys(d.sectionOrder,[...SECTIONS,...(langData().customSections||[]).map(s=>s.id)]).map(id=>sections[id]).join('')}`;
}
let resizeObserver;
function refreshPreview() {
  const page=document.querySelector('#resume-preview'); if (!page) return;
  page.className=`resume-page lang-${state.activeLang} ${draft().accent==='black'?'black':''}`;
  page.innerHTML=resumeMarkup();
  let font=draft().fontSize;
  const fits=()=> page.scrollHeight<=page.clientHeight+1 && page.scrollWidth<=page.clientWidth+1;
  page.style.setProperty('--resume-font',`${font}px`);
  if(draft().autoFit) {
    while(!fits() && font>12.67) { font=Math.max(12.67,font-.15); page.style.setProperty('--resume-font',`${font.toFixed(2)}px`); }
  }
  ui.fits=fits(); ui.font=font;
  const badge=document.querySelector('#page-badge');
  badge.textContent=ui.fits?`1 页 · ${(font*.75).toFixed(1)} pt`:'超出 1 页，请减少条目';
  badge.classList.toggle('over',!ui.fits);
  const area=document.querySelector('.paper-area'),wrap=document.querySelector('#paper-wrap');
  const scale=()=>{
    const style=getComputedStyle(area);
    const available=area.clientWidth-parseFloat(style.paddingLeft)-parseFloat(style.paddingRight);
    const s=Math.min(1,available/816);
    wrap.style.setProperty('--scale',s);wrap.style.width=`${816*s}px`;wrap.style.height=`${Math.max(1056,page.scrollHeight)*s}px`;
  };
  resizeObserver?.disconnect(); resizeObserver=new ResizeObserver(scale);resizeObserver.observe(area);scale();
}
function libraryView() {
  const l=langData();
  return `<div class="page-heading"><div><div class="eyebrow">EXPERIENCE LIBRARY</div><h1>你的经历，随时可用</h1><p>把完整经历放在这里，按条编辑、分类，再用于不同简历。</p></div><div class="heading-actions"><button data-action="import">${icon('upload')}导入经历</button><button class="primary" data-action="new-experience">${icon('plus')}添加经历</button></div></div>
  <div class="stats-row"><div class="stat"><strong>${l.experiences.length.toString().padStart(2,'0')}</strong><span>段工作经历</span></div><div class="stat"><strong>${allBullets().length.toString().padStart(2,'0')}</strong><span>条经历要点</span></div><div class="stat"><strong>${state.categories.length.toString().padStart(2,'0')}</strong><span>个求职方向</span></div></div>
  
  <div class="library-toolbar">${searchField()}${categoriesFilter()}<label class="check-label sort-toggle"><input type="checkbox" data-sort-alpha ${ui.alphabetical?'checked':''}>按首字母排序</label></div><div class="library-grid" id="library-grid">${libraryCards()}</div>`;
}
function libraryCards() {
  const groups=langData().experiences.map(e=>({e,bullets:e.bullets.filter(b=>filterBullet(e,b))})).filter(g=>g.bullets.length || (!ui.search && ui.category==='all'));
  if(!groups.length) return '<div class="empty-state"><h3>暂无符合条件的经历</h3><p>可以导入简历，或手动添加。</p></div>';
  const family=role=>{
    const value=String(role||'').toLowerCase();
    if(/counsel|律师|法务/.test(value))return state.activeLang==='en'?'Legal Counsel':'法务岗位';
    if(/specialist|专员/.test(value))return state.activeLang==='en'?'Legal Specialist':'法务专员';
    if(/paralegal|law clerk|律师助理/.test(value))return state.activeLang==='en'?'Paralegal / Law Clerk':'律师助理';
    if(/intern|实习/.test(value))return state.activeLang==='en'?'Legal Intern':'法律实习';
    return state.activeLang==='en'?'Other roles':'其他职位';
  };
  const grouped=new Map();
  for(const item of groups){const key=family(item.e.role);if(!grouped.has(key))grouped.set(key,[]);grouped.get(key).push(item);}
  return [...grouped.entries()].map(([title,items],groupIndex)=>`<details class="role-group" ${ui.search||ui.category!=='all'?'open':''}><summary class="role-group-summary"><span class="chevron">${icon('chevron')}</span><div><h2>${esc(title)}</h2><p>${items.length} 段经历 · ${items.reduce((n,item)=>n+item.e.bullets.length,0)} 条要点</p></div><span class="role-group-action">${groupIndex===0?'点击展开':''}</span></summary><div class="role-group-content">${items.map(({e,bullets})=>`<article class="library-card"><header class="library-card-header"><div><h3>${esc(e.role||'未填写职位')}</h3><p>${esc(e.company||'未填写公司')}</p><small>${esc(e.dates||'未填写时间')} · ${e.bullets.length} 条要点</small></div><button class="small" data-action="edit-experience" data-id="${esc(e.id)}">编辑经历</button></header>${bullets.map(b=>`<div class="library-bullet"><p>${esc(b.text)}</p><div class="library-bullet-footer">${tags(b)}<span class="source-label">${esc(b.sources.join(' / '))}</span><button class="quiet bullet-edit" data-action="edit-bullet" data-id="${esc(b.id)}" data-mode="library">编辑与分类</button></div></div>`).join('')}<footer class="library-card-bottom"><button class="quiet small" data-action="new-bullet" data-id="${esc(e.id)}">${icon('plus')}添加要点</button><button class="quiet small" data-action="batch-bullets" data-id="${esc(e.id)}">${icon('plus')}批量添加</button></footer></article>`).join('')}</div></details>`).join('');
}
function categoriesView() {
  return `<div class="page-heading"><div><div class="eyebrow">APPLICATION DIRECTIONS</div><h1>按方向，整理经历</h1><p>同一条经历可以放进多个分类。在简历制作页按分类筛选，再逐条选择。</p></div><button class="primary" data-action="new-category">${icon('plus')}新建分类</button></div><div class="categories-grid">${state.categories.map(c=>{
    const bullets=allBullets().filter(b=>b.categories.includes(c.id));
    const count=langData().experiences.filter(e=>e.bullets.some(b=>b.categories.includes(c.id))).length;
    return `<article class="category-card"><div class="category-top"><h3>${esc(c.name)}</h3>${icon('folder')}</div><p>${bullets.length} 条要点，来自 ${count} 段经历<br>${state.activeLang==='en'?'英文经历库':'中文经历库'}</p><div class="category-bottom"><button class="small" data-action="assign-category" data-id="${esc(c.id)}">选择条目</button><button class="quiet small" data-action="rename-category" data-id="${esc(c.id)}">改名</button><button class="quiet small danger" data-action="delete-category" data-id="${esc(c.id)}">删除</button></div></article>`;
  }).join('') || '<div class="empty-state"><h3>新建你的第一个求职方向</h3><p>例如营销、AI 或数据合规。</p></div>'}</div><p class="layout-note" style="margin-top:22px">分类名称在中英文之间共用，分类中的条目分别来自各自的经历库。</p>`;
}

function field(label,name,value='',options={}) {
  return `<div class="form-field ${options.full?'full':''}"><label for="field-${esc(name)}">${label}</label>${options.textarea?`<textarea id="field-${esc(name)}" name="${esc(name)}" rows="${options.rows||5}" ${options.required?'required':''}>${esc(value)}</textarea>`:`<input id="field-${esc(name)}" name="${esc(name)}" value="${esc(value)}" ${options.required?'required':''} ${options.type?`type="${options.type}"`:''} ${options.list?`list="${options.list}"`:''}>`}</div>`;
}
function openModal(title,body,onSubmit,{submit='保存',extra='',wide=false}={}) {
  modal.className=wide?'modal-wide':'';
  modal.innerHTML=`<form id="modal-form"><header class="modal-header"><h2 id="modal-title">${title}</h2><button type="button" class="quiet icon-button" data-close aria-label="关闭">${icon('close')}</button></header><div class="modal-body">${body}</div><footer class="modal-footer">${extra}<button type="button" data-close>取消</button>${onSubmit?`<button type="submit" class="primary" id="modal-submit">${submit}</button>`:''}</footer></form>`;
  modal.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>modal.close());
  modal.querySelector('form').onsubmit=async event=>{
    event.preventDefault();
    try { await onSubmit?.(new FormData(event.currentTarget)); }
    catch(error){ toast(error.message); }
  };
  if(!modal.open)modal.showModal();
  translateInterface(modal);
}
function done(message='已保存') { save();modal.close();render();toast(message); }
function confirmModal(title,message,callback) {
  openModal(title,`<p>${esc(message)}</p>`,()=>{callback();done('已完成');},{submit:'确认'});
}
function askName(title,value,callback) {
  openModal(title,field('名称','name',value,{required:true}),form=>{const name=form.get('name').trim();if(!name)throw new Error('请填写名称。');callback(name);done();});
}
function reorderModal(target) {
  const d=draft(),p=langData().profile,groups=orderedExperiences();
  const names={education:'教育经历',experience:'工作经历',certificates:'证书与语言',...Object.fromEntries((langData().customSections||[]).map(s=>[s.id,s.name]))};
  const list=(name,items)=>`<div class="reorder-list" data-sort-list="${esc(name)}">${items.map(([id,text],i)=>`<div class="reorder-row" data-key="${esc(id)}"><span class="reorder-position">${i+1}</span><span class="reorder-text">${esc(text)}</span><div class="move-actions"><button type="button" class="small" data-sort-move="-1" aria-label="上移" ${i===0?'disabled':''}>${icon('up')}上移</button><button type="button" class="small" data-sort-move="1" aria-label="下移" ${i===items.length-1?'disabled':''}>${icon('down')}下移</button></div></div>`).join('') || '<p class="muted">暂无条目。</p>'}</div>`;
  const certificates=p.certificates.split('\n').filter(line=>line.trim());
  const body=`<p>点击“上移”“下移”调整顺序，保存后右侧预览和导出会同步更新。排序仅用于当前这份简历。</p>
    <section class="reorder-group"><h3>简历各部分</h3>${list('sections',orderedKeys(d.sectionOrder,[...SECTIONS,...(langData().customSections||[]).map(s=>s.id)]).map(id=>[id,names[id]]))}</section>
    <section class="reorder-group"><h3>教育经历</h3>${list('education',orderedKeys(d.educationOrder,p.education.map(e=>e.id)).map(id=>[id,p.education.find(e=>e.id===id).school]))}</section>
    <section class="reorder-group"><h3>工作经历</h3>${list('experiences',groups.map(e=>[e.id,`${e.role} · ${e.company}`]))}</section>
    ${groups.map(e=>`<section class="reorder-group"><h3>${esc(e.role)} · 每条经历要点</h3><p class="muted">${esc(e.company)}</p>${list(`bullets-${e.id}`,e.bullets.map(b=>[b.id,d.overrides[b.id]??b.text]))}</section>`).join('')}
    <section class="reorder-group"><h3>证书与语言</h3>${list('certificates',orderedKeys(d.certificateOrder,certificates.map((_,i)=>i)).map(i=>[i,certificates[i]]))}</section>`;
  openModal('调整简历顺序',body,()=>{
    const keys=name=>[...modal.querySelectorAll('[data-sort-list]')].find(el=>el.dataset.sortList===name);
    const order=name=>[...keys(name).children].filter(el=>el.hasAttribute('data-key')).map(el=>el.dataset.key);
    d.sectionOrder=order('sections');d.educationOrder=order('education');d.certificateOrder=order('certificates').map(Number);
    d.order=orderedKeys(order('experiences'),langData().experiences.map(e=>e.id));
    const selected=d.order.flatMap(id=>groups.some(e=>e.id===id)?order(`bullets-${id}`):[]);
    d.selected=orderedKeys(selected,d.selected);
    done('顺序已保存，预览与导出已同步。');
  },{submit:'保存顺序',wide:true});
  modal.querySelectorAll('[data-sort-move]').forEach(button=>button.onclick=()=>{
    const row=button.closest('.reorder-row'),parent=row.parentElement;
    if(button.dataset.sortMove==='-1' && row.previousElementSibling)parent.insertBefore(row,row.previousElementSibling);
    else if(button.dataset.sortMove==='1' && row.nextElementSibling)parent.insertBefore(row.nextElementSibling,row);
    [...parent.children].forEach((el,i)=>{
      el.querySelector('.reorder-position').textContent=i+1;
      el.querySelector('[data-sort-move="-1"]').disabled=i===0;
      el.querySelector('[data-sort-move="1"]').disabled=i===parent.children.length-1;
    });
  });
  if(target){
    const list=[...modal.querySelectorAll('[data-sort-list]')].find(el=>el.dataset.sortList===target.group);
    const row=list && [...list.children].find(el=>el.dataset.key===target.key);
    if(row){
      row.classList.add('reorder-highlight');
      row.scrollIntoView({block:'center'});
      const control=row.querySelector('button:not(:disabled)');
      control?.focus({preventScroll:true});
    }
  }
}
function editProfile() {
  const p=clone(langData().profile);
  const body=`<p>基本信息由同语言的简历共用。各份简历可以在排版设置中选择是否显示教育、证书与语言。</p><div class="form-grid">${field('姓名','name',p.name)}${field('电话','phone',p.phone)}${field('邮箱','email',p.email)}${field('所在城市（可留空）','location',p.location)}</div><div class="inline-actions"><h3>教育经历</h3><button type="button" id="add-education" class="quiet small">添加教育经历</button></div><div id="education-fields"></div>${field('证书与语言（每行一项）','certificates',p.certificates,{textarea:true,rows:3})}`;
  openModal('基本信息',body,form=>{
    const education=[...modal.querySelectorAll('.education-entry')].map(el=>({id:el.dataset.id,school:el.querySelector('[name=school]').value.trim(),degree:el.querySelector('[name=degree]').value.trim(),dates:el.querySelector('[name=edu-dates]').value.trim()})).filter(e=>e.school||e.degree||e.dates);
    const certificates=form.get('certificates').trim();
    if(certificates!==p.certificates)for(const d of langData().drafts)delete d.certificateOrder;
    langData().profile={...p,...Object.fromEntries(['name','phone','email','location','certificates'].map(k=>[k,form.get(k).trim()])),education};done();
  });
  const addEducation=e=>{
    const div=document.createElement('div');div.className='education-entry';div.dataset.id=e.id;
    div.innerHTML=`${field('学校及地点','school',e.school)}${field('学位及补充信息','degree',e.degree)}${field('就读时间','edu-dates',e.dates)}<button type="button" class="quiet small danger">删除这条教育经历</button>`;
    div.querySelectorAll('input').forEach(input=>{
      const label=div.querySelector(`label[for="${input.id}"]`);
      input.id=`education-${e.id}-${input.name}`;if(label)label.htmlFor=input.id;
    });
    div.querySelector('button').onclick=()=>div.remove();modal.querySelector('#education-fields').append(div);
  };
  p.education.forEach(addEducation);
  modal.querySelector('#add-education').onclick=()=>addEducation({id:uid(),school:'',degree:'',dates:''});
}
function categoryCheckboxes(selected=[]) {
  return `<div class="form-field"><div class="category-label-row"><label>所属分类（可多选）</label><button type="button" class="quiet small add-category-inline" data-action="add-category-inline">${icon('plus')}增加分类</button></div><div class="category-checkboxes" data-category-boxes>${state.categories.map(c=>`<label class="check-label"><input type="checkbox" name="categories" value="${esc(c.id)}" ${selected.includes(c.id)?'checked':''}>${esc(c.name)}</label>`).join('')||'<span class="muted">尚无分类，可先增加一个分类。</span>'}</div><div class="category-add-inline hidden" data-category-add-form><input type="text" data-new-category-name placeholder="例如：诉讼方向" maxlength="40" aria-label="新分类名称"><button type="button" class="small primary" data-action="save-category-inline">保存</button><button type="button" class="quiet small" data-action="cancel-category-inline">取消</button></div></div>`;
}

function refreshModalCategories(newId) {
  const boxes=modal.querySelector('[data-category-boxes]');
  if(!boxes)return;
  const selected=new Set([...boxes.querySelectorAll('input[name="categories"]:checked')].map(input=>input.value));
  if(newId)selected.add(newId);
  boxes.innerHTML=state.categories.map(c=>`<label class="check-label"><input type="checkbox" name="categories" value="${esc(c.id)}" ${selected.has(c.id)?'checked':''}>${esc(c.name)}</label>`).join('');
}
function wireCategoryInline() {
  modal.querySelector('[data-action="add-category-inline"]')?.addEventListener('click',()=>{
    const form=modal.querySelector('[data-category-add-form]');form?.classList.remove('hidden');form?.querySelector('[data-new-category-name]')?.focus();
  });
  modal.querySelector('[data-action="cancel-category-inline"]')?.addEventListener('click',()=>modal.querySelector('[data-category-add-form]')?.classList.add('hidden'));
  modal.querySelector('[data-action="save-category-inline"]')?.addEventListener('click',()=>{
    const form=modal.querySelector('[data-category-add-form]'),input=form?.querySelector('[data-new-category-name]'),name=input?.value.trim();
    if(!name){toast('请填写分类名称。');input?.focus();return;}
    if(state.categories.some(c=>c.name===name)){toast('已存在同名分类。');input?.focus();return;}
    const category={id:uid(),name};state.categories.push(category);refreshModalCategories(category.id);input.value='';form.classList.add('hidden');save();toast(`已增加分类“${name}”，并已勾选。`);
  });
}
function findBullet(id) {
  for(const e of langData().experiences){const b=e.bullets.find(b=>b.id===id);if(b)return {e,b};}
  return {};
}
function editBullet(id,mode='library',experienceId) {
  const {e,b}=id?findBullet(id):{e:langData().experiences.find(e=>e.id===experienceId),b:null};
  const original=b?.text||'';
  const text=mode==='draft'?(draft().overrides[id]??original):original;
  openModal(mode==='draft'?'编辑当前简历要点':b?'编辑经历要点':'添加经历要点',`<p>${esc(e.role)} · ${esc(e.company)}<br>${mode==='draft'?'仅修改当前简历，经历库原文不变。':'修改经历库原文。未单独改写的简历将使用更新后的文字。'}</p>${field('经历内容','text',text,{textarea:true,rows:8,required:true})}${mode==='library'?categoryCheckboxes(b?.categories):''}${mode==='draft'&&draft().overrides[id]!==undefined?'<button type="button" id="restore-original" class="quiet small">恢复经历库原文</button>':''}`,form=>{
    const text=form.get('text').trim();if(!text)throw new Error('请填写经历内容。');
    if(mode==='draft'){ if(text===original)delete draft().overrides[id];else draft().overrides[id]=text; }
    else if(b){b.text=text;b.categories=form.getAll('categories');}
    else e.bullets.push({id:uid(),text,categories:form.getAll('categories'),sources:['手动输入']});
    done();
  },{extra:b&&mode==='library'?'<button type="button" class="quiet small danger" id="delete-bullet" style="margin-right:auto">删除要点</button>':''});
  wireCategoryInline();
  modal.querySelector('#restore-original')?.addEventListener('click',()=>{modal.querySelector('[name=text]').value=original;});
  modal.querySelector('#delete-bullet')?.addEventListener('click',()=>confirmModal('删除经历要点','这条要点也会从所有简历中移除。其他要点保持不变。',()=>{
    e.bullets=e.bullets.filter(x=>x.id!==id);for(const d of langData().drafts){d.selected=d.selected.filter(x=>x!==id);delete d.overrides[id];}
  }));
}
function editExperience(id,onlyDraft=false) {
  const original=langData().experiences.find(e=>e.id===id);
  const e=onlyDraft?{...original,...draft().metaOverrides[id]}:original||{role:'',company:'',dates:''};
  openModal(onlyDraft?'编辑当前简历的经历信息':id?'编辑经历':'添加经历',`<p>${onlyDraft?'仅修改当前简历中的职位、公司和时间。':'填写职位、公司和时间。每段经历可以有多个要点。'}</p>${!onlyDraft?`<div class="form-field"><label for="experience-section">所属章节</label><select name="section" id="experience-section">${[{id:'experience',name:'工作经历'},...(langData().customSections||[])].map(s=>`<option value="${esc(s.id)}" ${(e.section||'experience')===s.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select></div>`:''}${field('职位','role',e.role,{required:true,list:'role-alternatives'})}<datalist id="role-alternatives">${[original?.role,...(original?.alternatives||[])].filter(Boolean).map(t=>`<option value="${esc(t)}"></option>`).join('')}</datalist>${field('公司或项目名称','company',e.company,{required:true})}${field('时间','dates',e.dates,{required:true})}${!id?field('经历要点（每行一条）','bullets','',{textarea:true,rows:6}):''}`,form=>{
    const fields=Object.fromEntries(['role','company','dates'].map(k=>[k,form.get(k).trim()]));
    if(Object.values(fields).some(v=>!v))throw new Error('请填写职位、公司和时间。');
    if(onlyDraft)draft().metaOverrides[id]=fields;
    else if(original)Object.assign(original,fields,{section:form.get('section')});
    else {const eid=uid();langData().experiences.unshift({id:eid,...fields,section:form.get('section'),alternatives:[],bullets:splitBullets(form.get('bullets')).map(text=>({id:uid(),text,categories:[],sources:['手动输入']}))});for(const d of langData().drafts)d.order.unshift(eid);ui.openCards.add(eid);}
    done();
  },{extra:id&&!onlyDraft?'<button type="button" id="delete-experience" class="quiet small danger" style="margin-right:auto">删除经历</button>':''});
  modal.querySelector('#delete-experience')?.addEventListener('click',()=>confirmModal('删除整段经历','这段经历及所有要点也会从各份简历中移除。建议先下载数据备份。',()=>{
    const ids=new Set(original.bullets.map(b=>b.id));langData().experiences=langData().experiences.filter(e=>e.id!==id);
    for(const d of langData().drafts){d.selected=d.selected.filter(id=>!ids.has(id));d.order=d.order.filter(eid=>eid!==id);for(const bid of ids)delete d.overrides[bid];delete d.metaOverrides[id];}
  }));
}
function sectionsModal(){
  const sections=langData().customSections||[];
  openModal('管理章节',`<p>可添加实习、项目等章节。在经历库的“编辑经历”中选择所属章节。章节顺序可在“调整顺序”中修改。</p><div class="import-review"><strong>基本信息 · 教育经历 · 工作经历 · 证书与语言</strong></div>${sections.map(s=>`<div class="import-review">${field('章节名称',`section-${s.id}`,s.name)}</div>`).join('')}${field('添加新章节','new-section','')}`,form=>{
    for(const s of sections){const name=form.get(`section-${s.id}`).trim();if(!name)throw new Error('章节名称不能为空。');}
    for(const s of sections)s.name=form.get(`section-${s.id}`).trim();
    const name=form.get('new-section').trim();
    if(name){if(sections.some(s=>s.name===name))throw new Error('已有同名章节。');sections.push({id:uid(),name});}
    langData().customSections=sections;done();
  });
}
const splitBullets=text=>String(text||'').split('\n').map(t=>t.replace(/^\s*(?:[•●▪◦·]|[-*]\s|\d+[.)]\s)\s*/, '').trim()).filter(Boolean);
function editCategory(id) {
  const c=state.categories.find(c=>c.id===id);
  openModal(`选择“${esc(c.name)}”的条目`,`<p>勾选后，这些条目会出现在该方向的筛选结果中。这里的操作不会改变当前简历。</p><div class="category-assign-list">${langData().experiences.map(e=>`<h3>${esc(e.role)} · ${esc(e.company)}</h3>${e.bullets.map(b=>`<label class="check-label"><input type="checkbox" name="bullets" value="${esc(b.id)}" ${b.categories.includes(id)?'checked':''}><span>${esc(b.text)}</span></label>`).join('')}`).join('')||'<p class="muted">请先添加经历。</p>'}</div>`,form=>{
    const selected=new Set(form.getAll('bullets'));
    for(const b of allBullets()){b.categories=b.categories.filter(c=>c!==id);if(selected.has(b.id))b.categories.push(id);}done();
  },{wide:true});
}

function batchBullets(id) {
  const experience=langData().experiences.find(e=>e.id===id);
  openModal('批量添加经历条',`<p>${esc(experience.role)} · ${esc(experience.company)}</p><p>每段经历之间空一行；也可使用项目符号区分条目。</p>${field('经历内容','text','',{textarea:true,rows:12,required:true})}`,form=>{
    const entries=splitParagraphs(form.get('text'));
    if(!entries.length)throw new Error('请填写经历内容。');
    if(entries.length>100 || entries.some(t=>t.length>5000))throw new Error('一次最多添加 100 条，每条最多 5000 字。');
    const matches=entries.map(text=>experience.bullets.map(b=>({b,score:similarity(text,b.text)})).filter(m=>m.score>=.9).sort((a,b)=>b.score-a.score));
    openModal('核对批量添加',`<p>共识别 ${entries.length} 条。相似度基于文字计算，请逐条确认。</p>${entries.map((text,i)=>`<div class="import-review"><h3>新经历条 ${i+1}</h3><p>${esc(text)}</p>${matches[i].length?`<p class="error-text">与现有条目相似（${Math.round(matches[i][0].score*100)}%）</p><p>${esc(matches[i][0].b.text)}</p><div class="form-field"><label>如何处理</label><select name="choice-${i}"><option value="existing">保留已有条目</option><option value="new">用新内容替换已有条目</option><option value="both">两条都保留</option></select></div>`:'<p class="muted">将添加为新条目</p>'}</div>`).join('')}`,form=>{
      let added=0,replaced=0;
      entries.forEach((text,i)=>{
        const choice=matches[i].length?form.get(`choice-${i}`):'both';
        if(choice==='existing')return;
        if(choice==='new'){matches[i][0].b.text=text;replaced++;return;}
        experience.bullets.push({id:uid(),text,categories:[],sources:['批量输入']});added++;
      });
      done(`已添加 ${added} 条，替换 ${replaced} 条。`);
    },{submit:'确认添加',wide:true});
  },{submit:'识别并核对',wide:true});
}

function editLayout() {
  const d=draft();
  openModal('排版设置',`<p>沿用参考简历的单栏结构与 Letter 纸张。自动适配只调整字号，不改写或删除内容。</p><div class="form-field"><label for="font-size">正文字号</label><select name="fontSize" id="font-size">${[[12.67,'9.5 pt'],[13.4,'10 pt'],[14,'10.5 pt'],[14.67,'11 pt'],[16,'12 pt']].map(([v,t])=>`<option value="${v}" ${Math.abs(v-d.fontSize)<.02?'selected':''}>${t}</option>`).join('')}</select></div><div class="form-field"><label for="accent">标题颜色</label><select id="accent" name="accent"><option value="blue" ${d.accent==='blue'?'selected':''}>参考简历蓝色</option><option value="black" ${d.accent==='black'?'selected':''}>黑色</option></select></div><div class="form-field"><label class="check-label"><input type="checkbox" name="autoFit" ${d.autoFit?'checked':''}>自动调整至一页（最小 9.5 pt）</label><small>仍然超页时会提示你减少条目，并暂停导出，避免截断内容。</small></div><div class="form-field"><label class="check-label"><input type="checkbox" name="showEducation" ${d.showEducation?'checked':''}>显示教育经历</label></div><div class="form-field"><label class="check-label"><input type="checkbox" name="showCertificates" ${d.showCertificates?'checked':''}>显示证书与语言</label></div>`,form=>{
    d.fontSize=Number(form.get('fontSize'));d.accent=form.get('accent');for(const k of ['autoFit','showEducation','showCertificates'])d[k]=form.has(k);done();
  });
}
function importModal() {
  openModal('导入经历',`<p>上传文字型 PDF、TXT 文件或粘贴经历文本。按“职位与时间 → 公司 → 逐条要点”的格式识别；下一步可以逐项核对。</p><div class="import-zone"><label for="import-file">${icon('upload')} 选择 PDF 或文本文件<input id="import-file" type="file" accept=".pdf,.txt,.md"></label><p>文字型 PDF / UTF-8 TXT · 最大 20 MB</p></div><div id="file-status" class="muted" role="status"></div>${field('或粘贴经历文本','text','',{textarea:true,rows:10})}<small>识别结果需要核对；扫描 PDF 和 Word 文件请先复制文字再粘贴。</small>`,form=>{
    const text=form.get('text').trim();if(!text)throw new Error('请上传文件或粘贴经历内容。');
    const parsed=parseResume(text);
    if(!parsed.experiences.length)throw new Error('未识别到工作经历。请保留职位、时间、公司和每条要点前的 • 或 -。');
    reviewImport(parsed,modal.dataset.source||'粘贴导入');
  },{submit:'识别并核对',wide:true});
  modal.dataset.source='粘贴导入';
  modal.querySelector('#import-file').onchange=async event=>{
    const file=event.target.files[0];if(!file)return;
    const status=modal.querySelector('#file-status'),submit=modal.querySelector('#modal-submit');
    if(file.size>20*1024*1024){status.textContent='文件不能超过 20 MB。';return;}
    status.textContent='正在本地读取文件，扫描件可能需要稍等。';submit.disabled=true;
    try {
      const data={text:file.name.toLowerCase().endsWith('.pdf')?await extractPdf(file):await file.text(),method:'text'};
      if(!data.text.trim())throw new Error('未读取到文字，请粘贴经历文本。');
      modal.querySelector('[name=text]').value=data.text;modal.dataset.source=file.name;
      status.textContent=`已读取 ${file.name}${data.method==='ocr'?'（系统文字识别，请仔细核对）':''}`;
    }catch(error){status.textContent=error.message;status.className='error-text';}
    finally{submit.disabled=false;}
  };
}
function reviewImport(parsed,source) {
  const norm=t=>t.toLowerCase().replace(/[^\p{L}\p{N}]/gu,'');
  const match=e=>langData().experiences.find(x=>{const a=norm(x.company.split('|').at(-1)),b=norm(e.company.split('|').at(-1));return a&&b&&(a===b||a.includes(b)||b.includes(a));});
  openModal('核对识别结果',`<div class="parse-note">识别到 ${parsed.experiences.length} 段工作经历、${parsed.education.length} 段教育经历。请逐项核对。</div><div class="import-review"><h3>基本信息</h3><p>勾选需要导入的字段，将替换当前对应内容。</p>${[['name','姓名'],['phone','电话'],['email','邮箱']].map(([key,label])=>`<label class="check-label"><input type="checkbox" name="import-${key}" ${parsed.profile[key]&&!langData().profile[key]?'checked':''}>导入${label}</label>${field(label,`profile-${key}`,parsed.profile[key])}`).join('')}<label class="check-label"><input type="checkbox" name="import-order">按识别的章节顺序排列当前简历</label><p class="muted">${esc(parsed.sectionOrder.join(' → ')||'未识别')}</p></div>${parsed.education.map((e,i)=>`<div class="import-review"><div class="inline-actions"><h3>教育经历 ${i+1}</h3><label class="check-label"><input type="checkbox" name="education-include-${i}" checked>导入这段教育经历</label></div>${field('学校及地点',`education-school-${i}`,e.school)}${field('学位及补充信息',`education-degree-${i}`,e.degree)}${field('就读时间',`education-dates-${i}`,e.dates)}</div>`).join('')}${parsed.warnings.length?`<p class="error-text">${parsed.warnings.map(esc).join('；')}</p>`:''}${parsed.experiences.map((e,i)=>`<div class="import-review" data-review="${i}"><div class="inline-actions"><h3>经历 ${i+1}</h3><label class="check-label"><input type="checkbox" name="include-${i}" checked>导入这段经历</label></div>${field('职位',`role-${i}`,e.role)}${field('公司或项目',`company-${i}`,e.company)}${field('时间',`dates-${i}`,e.dates)}${field('经历要点（每行一条）',`bullets-${i}`,e.bullets.join('\n'),{textarea:true,rows:Math.min(8,Math.max(3,e.bullets.length*2))})}<div class="form-field"><label for="merge-${i}">添加到</label><select name="merge-${i}" id="merge-${i}"><option value="new">新建一段经历</option>${langData().experiences.map(x=>`<option value="${esc(x.id)}" ${match(e)?.id===x.id?'selected':''}>已有经历：${esc(x.company)}</option>`).join('')}</select></div></div>`).join('')}`,form=>{
    const entries=[];
    parsed.experiences.forEach((_,i)=>{
      if(!form.has(`include-${i}`))return;
      const role=form.get(`role-${i}`).trim(),company=form.get(`company-${i}`).trim(),dates=form.get(`dates-${i}`).trim(),bullets=splitBullets(form.get(`bullets-${i}`));
      if(!role||!company||!dates||!bullets.length)throw new Error(`请补全经历 ${i+1} 的职位、公司、时间与至少一条要点。`);
      entries.push({role,company,dates,bullets,merge:form.get(`merge-${i}`),section:parsed.experiences[i].section||'experience'});
    });
    const education=parsed.education.flatMap((_,i)=>{
      if(!form.has(`education-include-${i}`))return [];
      const item={school:form.get(`education-school-${i}`).trim(),degree:form.get(`education-degree-${i}`).trim(),dates:form.get(`education-dates-${i}`).trim()};
      if(!item.school)throw new Error(`请填写教育经历 ${i+1} 的学校。`);
      return [item];
    });
    if(!entries.length && !education.length && !['name','phone','email'].some(k=>form.has(`import-${k}`)))throw new Error('请至少选择一段经历或一项基本信息。');
    for(const item of education){
      const duplicate=langData().profile.education.some(existing=>norm(existing.school)===norm(item.school) && norm(existing.degree)===norm(item.degree) && norm(existing.dates)===norm(item.dates));
      if(!duplicate)langData().profile.education.push({id:uid(),...item});
    }
    for(const k of ['name','phone','email'])if(form.has(`import-${k}`))langData().profile[k]=form.get(`profile-${k}`).trim();
    langData().customSections ||= [];
    const sectionIds={experience:'experience'};
    for(const section of parsed.customSections||[]){
      let existing=langData().customSections.find(s=>s.name.toLocaleLowerCase()===section.name.toLocaleLowerCase());
      if(!existing){existing={id:uid(),name:section.name};langData().customSections.push(existing);}
      sectionIds[`custom:${section.name}`]=existing.id;
    }
    if(parsed.sectionOrder.length && (form.has('import-order') || !draft().sectionOrder))draft().sectionOrder=parsed.sectionOrder.map(id=>sectionIds[id]||id);
    let added=0;
    for(const item of entries){
      let e=langData().experiences.find(e=>e.id===item.merge);
      if(!e){e={id:uid(),role:item.role,company:item.company,dates:item.dates,section:sectionIds[item.section]||'experience',alternatives:[],bullets:[]};langData().experiences.push(e);for(const d of langData().drafts)d.order.push(e.id);}
      for(const text of item.bullets){
        if(!e.bullets.some(b=>norm(b.text)===norm(text))){e.bullets.push({id:uid(),text,categories:[],sources:[source]});added++;}
      }
      ui.openCards.add(e.id);
    }
    done(`导入完成，新增 ${added} 条要点。`);
  },{submit:'确认加入经历库',wide:true});
}
function download(blob,filename) {
  const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function backup() { download(new Blob([JSON.stringify(state,null,2)],{type:'application/json'}),`resume-backup-${new Date().toISOString().slice(0,10)}.json`);toast('备份已下载，包含中英文经历库和所有简历。'); }
function accountModal(){
  if(!cloud?.enabled)return;
  const conflict=cloud.conflict;
  openModal('账户与同步',`<p>登录账号：${esc(cloud.user?.email || '登录已过期')}<br>当前状态：${esc(cloud.label)}</p>${conflict?'<div class="notice">另一台设备的资料也有更新。请先下载本机备份，再选择保留哪个版本，避免覆盖你需要的修改。</div><div class="account-actions"><button type="button" id="sync-backup">下载本机备份</button><button type="button" id="use-cloud">使用云端版本</button><button type="button" id="use-local">使用本机版本</button></div>':`<p>${cloud.status==='expired'?'请重新登录，本机未同步的修改会保留。':'同一账号登录后会读取云端资料。离线修改先保存在本机，恢复网络后继续同步。'}</p><div class="account-actions"><button type="button" id="sync-now">立即同步</button><button type="button" id="sync-backup">下载数据备份</button><button type="button" id="logout">保存后退出登录</button>${cloud.status==='expired'?'<button type="button" id="relogin">重新登录</button>':''}</div>`}<p class="muted" style="margin-top:18px">从原来的本机网站迁移：先在原网站下载备份，再在这里使用“恢复备份”，即可把最近的编辑同步到其他设备。</p>${cloud.lastError?`<p class="error-text">${esc(cloud.lastError)}</p>`:''}`,null);
  modal.querySelector('#sync-backup').onclick=backup;
  modal.querySelector('#sync-now')?.addEventListener('click',async()=>{modal.close();await cloud.refresh();accountModal();});
  modal.querySelector('#logout')?.addEventListener('click',async()=>{try{await cloud.logout();}catch(error){toast(error.message);}});
  modal.querySelector('#relogin')?.addEventListener('click',()=>location.reload());
  for(const [id,choice,label] of [['use-cloud','remote','云端'],['use-local','local','本机']]){
    modal.querySelector(`#${id}`)?.addEventListener('click',()=>openModal(`使用${label}版本`,`<p>确认使用${label}版本作为最新资料吗？另一版本不会与它自动合并；请先下载需要保留的数据备份。</p>`,async()=>{
      await cloud.resolve(choice);modal.close();render();toast('版本已确认，已同步。');
    },{submit:'确认使用'}));
  }
}
function restore() {
  openModal('恢复数据备份','<p>选择之前下载的 JSON 备份。确认恢复后，会替换当前浏览器中的中英文经历库、分类和简历。</p><div class="form-field"><label for="restore-file">备份文件</label><input type="file" id="restore-file" accept=".json" required></div><p class="muted">建议先关闭此窗口，下载当前数据的备份，再进行恢复。</p>',async()=>{
    const file=modal.querySelector('#restore-file').files[0];if(!file)throw new Error('请选择备份文件。');
    if(file.size>20*1024*1024)throw new Error('备份文件不能超过 20 MB。');
    let data;try{data=JSON.parse(await file.text());}catch{throw new Error('备份不是有效的 JSON 文件。');}
    if(!validState(data))throw new Error('备份结构不完整，未修改当前数据。');
    confirmModal('确认恢复备份','将用所选备份替换当前全部数据。',()=>{state=data;migrateState(state);ui.category='all';ui.search='';ui.tab='library';});
  },{submit:'读取备份'});
}
function exportModal() {
  refreshPreview();
  if(!ui.fits){toast('内容超出一页。请减少条目或调整排版后导出。');return;}
  openModal('导出简历','<p>打开浏览器打印窗口，选择“保存为 PDF”。纸张选择 Letter，边距选择无，并关闭页眉和页脚。</p><p>此版本暂不支持直接导出图片。</p><button type="button" class="primary" id="print-resume">打印或保存 PDF</button>',null);
  modal.querySelector('#print-resume').onclick=()=>{modal.close();window.print();};
}

app.addEventListener('pointermove',event=>{
  const wrap=event.target.closest('#paper-wrap');if(!wrap || event.pointerType==='touch')return;
  wrap.style.setProperty('--hint-x',`${Math.max(8,Math.min(event.clientX+16,innerWidth-180))}px`);
  wrap.style.setProperty('--hint-y',`${Math.max(8,Math.min(event.clientY+18,innerHeight-48))}px`);
});
app.addEventListener('keydown',event=>{
  if(event.target.id==='paper-wrap' && ['Enter',' '].includes(event.key)){
    event.preventDefault();reorderModal();
  }
});
app.addEventListener('input',event=>{
  if(event.target.id!=='search')return;
  ui.search=event.target.value;
  const list=document.querySelector('#selection-list'),grid=document.querySelector('#library-grid');
  if(list)list.innerHTML=selectionList();if(grid)grid.innerHTML=libraryCards();
});
app.addEventListener('change',event=>{
  const target=event.target;
  if(target.hasAttribute('data-sort-alpha')){ui.alphabetical=target.checked;render();}
  else if(target.dataset.select){
    const id=target.dataset.select;
    draft().selected=target.checked?[...new Set([...draft().selected,id])]:draft().selected.filter(x=>x!==id);
    save();render();
  }else if(target.id==='draft-select'){langData().activeDraft=target.value;save();render();}
});
app.addEventListener('click',event=>{
  const button=event.target.closest('[data-action]');if(!button)return;
  const {action,id,mode}=button.dataset;
  if(action==='navigate'){ui.route=id;ui.search='';ui.category='all';render();location.hash=id;}
  else if(action==='language'){state.activeLang=id;ui.search='';ui.category='all';ui.tab='library';save();render();}
  else if(action==='interface-language'){setInterfaceLanguage(id);render();}
  else if(action==='tab'){ui.tab=id;render();}
  else if(action==='filter'){ui.category=id;render();}
  else if(action==='profile')editProfile();
  else if(action==='sections')sectionsModal();
  else if(action==='reorder')reorderModal();
  else if(action==='preview-reorder'){
    const wrap=event.target.closest('#paper-wrap'),selection=window.getSelection();
    if(wrap && selection && !selection.isCollapsed && wrap.contains(selection.anchorNode))return;
    const entry=event.target.closest('[data-preview-sort]');
    reorderModal(entry?{group:entry.dataset.previewSort,key:entry.dataset.previewKey}:undefined);
  }
  else if(action==='layout')editLayout();
  else if(action==='import')importModal();
  else if(action==='new-experience')editExperience();
  else if(action==='edit-experience')editExperience(id);
  else if(action==='edit-draft-meta')editExperience(id,true);
  else if(action==='edit-bullet')editBullet(id,mode);
  else if(action==='new-bullet')editBullet(null,'library',id);
  else if(action==='batch-bullets')batchBullets(id);
  else if(action==='add-category-inline'){
    const form=modal.querySelector('[data-category-add-form]');form?.classList.remove('hidden');
    form?.querySelector('[data-new-category-name]')?.focus();
  }
  else if(action==='cancel-category-inline')modal.querySelector('[data-category-add-form]')?.classList.add('hidden');
  else if(action==='save-category-inline'){
    const form=modal.querySelector('[data-category-add-form]'),input=form?.querySelector('[data-new-category-name]'),name=input?.value.trim();
    if(!name){toast('请填写分类名称。');input?.focus();return;}
    if(state.categories.some(c=>c.name===name)){toast('已存在同名分类。');input?.focus();return;}
    const category={id:uid(),name};state.categories.push(category);refreshModalCategories(category.id);input.value='';form.classList.add('hidden');save();toast(`已增加分类“${name}”，并已勾选。`);
  }
  else if(action==='remove-bullet'){draft().selected=draft().selected.filter(x=>x!==id);save();render();}
  else if(action==='clear-selection')confirmModal('清空当前简历的经历选择','只清空当前简历的勾选，经历库与其他简历保持不变。',()=>{draft().selected=[];});
  else if(action==='rename-draft')askName('修改简历名称',draft().name,name=>draft().name=name);
  else if(action==='copy-draft')askName('另存一份简历',`${draft().name} 副本`,name=>{const d={...clone(draft()),id:uid(),name};langData().drafts.push(d);langData().activeDraft=d.id;});
  else if(action==='new-draft')askName('新建简历',state.activeLang==='en'?'New Resume':'新简历',name=>{const d={...clone(SEED.languages.en.drafts[0]),id:uid(),name,selected:[],order:langData().experiences.map(e=>e.id),overrides:{},metaOverrides:{}};langData().drafts.push(d);langData().activeDraft=d.id;});
  else if(action==='delete-draft')confirmModal('删除当前简历','经历库与其他简历保持不变。',()=>{langData().drafts=langData().drafts.filter(d=>d.id!==draft().id);langData().activeDraft=langData().drafts[0].id;});
  else if(action==='new-category')askName('新建分类','',name=>{if(state.categories.some(c=>c.name===name))throw new Error('已存在同名分类。');state.categories.push({id:uid(),name});});
  else if(action==='rename-category')askName('修改分类名称',categoryName(id),name=>{if(state.categories.some(c=>c.id!==id&&c.name===name))throw new Error('已存在同名分类。');state.categories.find(c=>c.id===id).name=name;});
  else if(action==='delete-category')confirmModal('删除分类','只移除分类，分类中的经历要点仍保留在经历库中。',()=>{state.categories=state.categories.filter(c=>c.id!==id);for(const l of Object.values(state.languages))for(const e of l.experiences)for(const b of e.bullets)b.categories=b.categories.filter(c=>c!==id);if(ui.category===id)ui.category='all';});
  else if(action==='assign-category')editCategory(id);
  else if(action==='backup')backup();
  else if(action==='account')accountModal();
  else if(action==='restore')restore();
  else if(action==='export')exportModal();
  else if(action==='move-experience'){
    const groups=orderedExperiences(),index=groups.findIndex(e=>e.id===id),other=groups[index+Number(button.dataset.direction)];
    if(other){const ids=groups.map(e=>e.id),i=ids.indexOf(id),j=ids.indexOf(other.id);[ids[i],ids[j]]=[ids[j],ids[i]];draft().order=[...ids,...langData().experiences.map(e=>e.id).filter(id=>!ids.includes(id))];save();render();}
  }else if(action==='move-bullet'){
    const {e}=findBullet(id),ids=draft().selected.filter(id=>e.bullets.some(b=>b.id===id)),i=ids.indexOf(id),other=ids[i+Number(button.dataset.direction)];
    if(other){const a=draft().selected.indexOf(id),b=draft().selected.indexOf(other);[draft().selected[a],draft().selected[b]]=[draft().selected[b],draft().selected[a]];save();render();}
  }
});
window.addEventListener('hashchange',()=>{
  const route=location.hash.slice(1);if(['editor','library','categories'].includes(route)&&ui.route!==route){ui.route=route;ui.search='';ui.category='all';render();}
});
if(['editor','library','categories'].includes(location.hash.slice(1)))ui.route=location.hash.slice(1);
if(migrated)save();
editorReady=true;
render();
if(initialError)toast(initialError);
