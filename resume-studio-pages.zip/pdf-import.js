import * as pdfjs from './vendor/pdfjs/pdf.min.mjs';

pdfjs.GlobalWorkerOptions.workerSrc = new URL('./vendor/pdfjs/pdf.worker.min.mjs', import.meta.url).href;

export async function extractPdf(file) {
  const document = await pdfjs.getDocument({data:await file.arrayBuffer(),disableFontFace:true}).promise;
  try {
    if(document.numPages>20)throw new Error('请上传不超过 20 页的 PDF。');
    const pages=[];
    for(let i=1;i<=document.numPages;i++){
      const page=await document.getPage(i);
      const content=await page.getTextContent();
      const lines=[];
      for(const item of content.items){
        if(!('str' in item))continue;
        const y=item.transform[5];
        const line=lines.find(existing=>Math.abs(existing.y-y)<3);
        if(line)line.items.push({x:item.transform[4],text:item.str});
        else lines.push({y,items:[{x:item.transform[4],text:item.str}]});
      }
      const text=lines.sort((a,b)=>b.y-a.y).map(line=>line.items.sort((a,b)=>a.x-b.x).map(item=>item.text).join(' ').replace(/\s+/g,' ').trim()).filter(Boolean).join('\n');
      if(text.trim().length<30)throw new Error(`第 ${i} 页没有足够的可复制文字，可能是扫描件。请先复制识别后的文字并粘贴导入。`);
      pages.push(text);
    }
    return pages.join('\n');
  }finally{await document.destroy();}
}
